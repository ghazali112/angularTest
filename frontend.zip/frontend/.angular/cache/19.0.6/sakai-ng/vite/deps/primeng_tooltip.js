import {
  Tooltip,
  TooltipClasses,
  TooltipModule,
  TooltipStyle
} from "./chunk-WVZ6SRAO.js";
import "./chunk-5G7WYC4N.js";
import "./chunk-5H5CNZCN.js";
import "./chunk-FVGBINOL.js";
import "./chunk-TZJOXRYV.js";
import "./chunk-ASBIYBWG.js";
import "./chunk-US7LRVFB.js";
import "./chunk-RYQGQIW4.js";
import "./chunk-GFVF2TMO.js";
import "./chunk-PXYLXCRT.js";
import "./chunk-UMAXZX7C.js";
import "./chunk-SAS3ZIMR.js";
import "./chunk-4N4GOYJH.js";
import "./chunk-5OPE3T2R.js";
import "./chunk-FHTVLBLO.js";
import "./chunk-WDMUDEB6.js";
export {
  Tooltip,
  TooltipClasses,
  TooltipModule,
  TooltipStyle
};
//# sourceMappingURL=primeng_tooltip.js.map
