import {
  Badge,
  BadgeClasses,
  BadgeDirective,
  BadgeModule,
  BadgeStyle
} from "./chunk-QFZST6LM.js";
import "./chunk-FVGBINOL.js";
import "./chunk-TZJOXRYV.js";
import "./chunk-ASBIYBWG.js";
import "./chunk-US7LRVFB.js";
import "./chunk-RYQGQIW4.js";
import "./chunk-GFVF2TMO.js";
import "./chunk-PXYLXCRT.js";
import "./chunk-UMAXZX7C.js";
import "./chunk-SAS3ZIMR.js";
import "./chunk-4N4GOYJH.js";
import "./chunk-5OPE3T2R.js";
import "./chunk-FHTVLBLO.js";
import "./chunk-WDMUDEB6.js";
export {
  Badge,
  BadgeClasses,
  BadgeDirective,
  BadgeModule,
  BadgeStyle
};
//# sourceMappingURL=primeng_badge.js.map
