import {
  Paginator,
  PaginatorClasses,
  PaginatorModule,
  PaginatorStyle
} from "./chunk-GCWHHMI5.js";
import "./chunk-OXH2XA5T.js";
import "./chunk-CPCQEFJD.js";
import "./chunk-EWQQ76VU.js";
import "./chunk-PZZSU4WG.js";
import "./chunk-WVZ6SRAO.js";
import "./chunk-AKDE7NTD.js";
import "./chunk-RT5T4UBR.js";
import "./chunk-IXMJWOLJ.js";
import "./chunk-WJXMSFVI.js";
import "./chunk-5G7WYC4N.js";
import "./chunk-P73PIM3P.js";
import "./chunk-5H5CNZCN.js";
import "./chunk-IAXCDWVV.js";
import "./chunk-7W7N6VVX.js";
import "./chunk-FVGBINOL.js";
import "./chunk-TZJOXRYV.js";
import "./chunk-ASBIYBWG.js";
import "./chunk-US7LRVFB.js";
import "./chunk-RYQGQIW4.js";
import "./chunk-GFVF2TMO.js";
import "./chunk-PXYLXCRT.js";
import "./chunk-J2347JD2.js";
import "./chunk-UMAXZX7C.js";
import "./chunk-SAS3ZIMR.js";
import "./chunk-4N4GOYJH.js";
import "./chunk-5OPE3T2R.js";
import "./chunk-FHTVLBLO.js";
import "./chunk-WDMUDEB6.js";
export {
  Paginator,
  PaginatorClasses,
  PaginatorModule,
  PaginatorStyle
};
//# sourceMappingURL=primeng_paginator.js.map
